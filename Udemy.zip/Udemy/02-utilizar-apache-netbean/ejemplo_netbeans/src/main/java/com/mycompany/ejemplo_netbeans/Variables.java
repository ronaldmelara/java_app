/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo_netbeans;

/**
 *
 * @author melaragalaz
 */
public class Variables {
    public static void main(String[] args) {
        /*Scanner sn = new Scanner(System.in);
        sn.useDelimiter("\n");
        sn.useLocale(Locale.US);*/
        System.out.println("Test");
        byte a = 5;
        short b = 200;
        int c = 1000000;
        long d= 100000000L;
        
        char e = 'a';
        double f = 4.5;
        float g = 4.5f;
        String h = "Hola Mundo";
        String h2 = new String("hola mundo 2");
        boolean i = true;
    }
}
