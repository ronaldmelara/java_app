package com.javatechnolesson.services;
import com.javatechnolesson.model.Persona;

public interface IPersonaServices {
    public void registrar(Persona persona);
}
